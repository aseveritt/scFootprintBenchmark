
findMotifsGenome.pl \
../03_peakcalls/HEPG2_filt_500bp.exclusion.bed \
hg38r \
./motif_enrichment/HEPG2/ \
-size 200 \
-mknown ../09_simPWMs/00_constructing_PWMs/JASPAR2022_CORE_vertebrates_non-redundant_pfms_homer.motif \
-nomotif \
-p 15 \
-dumpFasta \
-genomeBg

findMotifsGenome.pl \
../03_peakcalls/K562_filt_500bp.exclusion.bed \
hg38r \
./motif_enrichment/K562/ \
-size 200 \
-mknown ../09_simPWMs/00_constructing_PWMs/JASPAR2022_CORE_vertebrates_non-redundant_pfms_homer.motif \
-nomotif \
-p 15 \
-dumpFasta \
-genomeBg

findMotifsGenome.pl \
../03_peakcalls/GM12878_filt_500bp.exclusion.bed \
hg38r \
./motif_enrichment/GM12878/ \
-size 200 \
-mknown ../09_simPWMs/00_constructing_PWMs/JASPAR2022_CORE_vertebrates_non-redundant_pfms_homer.motif \
-nomotif \
-p 15 \
-dumpFasta \
-genomeBg

findMotifsGenome.pl \
../03_peakcalls/SKNSH_filt_500bp.exclusion.bed \
hg38r \
./motif_enrichment/SKNSH/ \
-size 200 \
-mknown ../09_simPWMs/00_constructing_PWMs/JASPAR2022_CORE_vertebrates_non-redundant_pfms_homer.motif \
-nomotif \
-p 15 \
-dumpFasta \
-genomeBg

findMotifsGenome.pl \
../03_peakcalls/MCF7_filt_500bp.exclusion.bed \
hg38r \
./motif_enrichment/MCF7/ \
-size 200 \
-mknown ../09_simPWMs/00_constructing_PWMs/JASPAR2022_CORE_vertebrates_non-redundant_pfms_homer.motif \
-nomotif \
-p 15 \
-dumpFasta \
-genomeBg


