OUT_FORMAT_CONVERSION = {
    "t": "",
    "b": "b",
    "u": "bu",
}
